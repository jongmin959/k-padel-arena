import "./globals.css";
export const metadata={title:"K-PADEL ARENA",description:"빠델 예약 · 매칭 · 대회 · 랭킹 플랫폼"};
export default function RootLayout({children}){return <html lang="ko"><body>{children}</body></html>}
